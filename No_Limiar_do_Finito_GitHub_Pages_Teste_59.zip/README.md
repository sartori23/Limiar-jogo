# No Limiar do Finito — Teste 59

Site estático em HTML5/Canvas e JavaScript preparado para GitHub Pages.

## Como publicar no GitHub Pages

1. Faça login em https://github.com/ e crie um repositório **público** chamado `no-limiar-do-finito`.
2. Extraia o pacote `No_Limiar_do_Finito_GitHub_Pages_Teste_59.zip` no computador.
3. Dentro do repositório, selecione **Add file > Upload files** e envie os arquivos extraídos, principalmente `index.html`, na **raiz** do repositório. Confirme em **Commit changes**.
4. Abra **Settings > Pages**. Em **Build and deployment > Source**, selecione **Deploy from a branch**. Em **Branch**, escolha `main` e `/ (root)`. Salve.
5. Quando o GitHub indicar a publicação, abra o endereço `https://SEU-USUARIO.github.io/no-limiar-do-finito/`, substituindo `SEU-USUARIO` pelo nome de usuário da sua conta.

## Nas próximas versões

Para atualizar o jogo, basta substituir o arquivo `index.html` no repositório e fazer novo commit. O endereço para jogar não muda. Pode levar um pouco para a publicação aparecer; recarregue a página caso veja uma versão em cache.

## Conteúdo

- `index.html` — jogo completo, versão Teste 59 (HTML autossuficiente, com imagens e recursos integrados)
- `.nojekyll` — publicação estática sem processamento Jekyll
- `README.md` — instruções de instalação e atualização

**Atenção:** o GitHub Pages disponibiliza os arquivos da página publicamente. Verifique as permissões de uso das artes e dos demais materiais antes de publicar. Não inclua dados pessoais nem credenciais no repositório.
